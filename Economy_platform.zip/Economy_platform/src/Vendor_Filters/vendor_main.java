package Vendor_Filters;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.dataconn;

import services.V_Service_add;
import v_model.VendorInfo;
import v_model.Vendordetails;

public class vendor_main extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession hs=request.getSession();
		VendorInfo user=(VendorInfo)hs.getAttribute("user");
		String v_uid=user.getVendor_UserId();
		
		
		System.out.println("vebdor_main" + v_uid);
		try {
	
			 Vendordetails vd = V_Service_add.checkven(v_uid);
			 
    
			 if(vd!=null)
		        {
		        	
		       	 hs.setAttribute("vd", vd);
		       //	VendorInfo user=(VendorInfo)request.getAttribute("user");
		       	 
		       	 
		        	RequestDispatcher rd = request.getRequestDispatcher("vendor_main1.jsp?msg3=Successfully logged in");
		        	rd.forward(request, response);
		        	
		        }
		        else
		        {
		        	RequestDispatcher rd = request.getRequestDispatcher("vendor_main.jsp?errmsg3=INVALID USER...!!!!!!!!!!!");
		            rd.forward(request, response);
		        }
		        }catch(Exception ex)
		        {
		        	/*RequestDispatcher rd = request.getRequestDispatcher("views/error.jsp?errmsg=" + ex.getMessage());
		            rd.forward(request, response);*/
		        	
		        }
		        
				
			}
		
	

	
}






