package Vendor_Filters;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Types;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dao.dataconn;

import P_model.Product_detail;
import P_model.Service;
import services.P_service_add;
import services.V_Service_add;
import v_model.VendorInfo;
import v_model.Vendordetails;


public class Product extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public Product() {
        super();
        
    }
    
    

public static String getP_Id()
{
	int id = 0;
	String id1="";
	try{
		Connection con = dataconn.connect();
		PreparedStatement ps= null;
		String query= "select max(product_Id) from product_details";
		ps= con.prepareStatement(query);
		ResultSet rs = ps.executeQuery();
		if(rs.next()==false)
		{
			id=0;
		}
		else
		{
			id=Integer.parseInt(rs.getString(1).substring(2));
			System.out.println(id);
		}
		id=id+1;
		id1="P";
		id1=id1+String.format("%04d", id);
	}catch(Exception e)
	{
		System.out.println(e);
	}
	return id1;
}
public static String getV_Id()
{
	int id = 0;
	String id1="";
	try{
		Connection con = dataconn.connect();
		PreparedStatement ps= null;
		String query= "select max(product_Id) from service_details";
		ps= con.prepareStatement(query);
		ResultSet rs = ps.executeQuery();
		if(rs.next()==false)
		{
			id=0;
		}
		else
		{
			id=Integer.parseInt(rs.getString(1).substring(2));
			System.out.println(id);
		}
		id=id+1;
		id1="S";
		id1=id1+String.format("%04d", id);
	}catch(Exception e)
	{
		System.out.println(e);
	}
	return id1;
}

	
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{

		HttpSession hts=request.getSession();
		//hts.setAttribute("user",user);
		VendorInfo user=(VendorInfo)hts.getAttribute("user");
		hts.setAttribute("user", user);
		
		String product_Id=getP_Id();
		Connection con = dataconn.connect();
		try{
			String query = "select * from product_details";
		PreparedStatement ps = con.prepareStatement(query);
		//VendorInfo user=(VendorInfo)request.getAttribute("user");
		//request.getSession().setAttribute("user", user);
		System.out.println("p1");
		ResultSet rs = ps.executeQuery();
		System.out.println("p11");
		String t = request.getParameter("selecttype");
		if(t.equals("Product"))
		{
			String t1= request.getParameter("choose");
			if(t1.equals("Add other category..."))
			{
				t1=request.getParameter("new_cat");
			}
			System.out.println(t1);
			int l= Integer.parseInt(request.getParameter("length"));
			System.out.println(l);
			int b= Integer.parseInt(request.getParameter("breadth"));
			int h= Integer.parseInt(request.getParameter("height"));
			String c= request.getParameter("color");
			String m= request.getParameter("material");
			String br= request.getParameter("brand");
			int p= Integer.parseInt(request.getParameter("price"));
			String de= request.getParameter("desc");
			System.out.println(de);
			String s= user.getVendor_UserId();
			System.out.println(s);
			System.out.println("p2");
			Product_detail p1 = new Product_detail(product_Id,l,b,h,p,s,t,t1,c,m,br,de);
			request.getRequestDispatcher("vendor_main2.jsp?p2=Product Added Successfully").forward(request, response);
			hts.setAttribute("p1", p1);
			
			 String query1 = "insert into Product_details values(?,?,?,?,?,?,?,?,?,?,?,?)" ;
	         ps=con.prepareStatement(query1);
	   
			
			ps.setString(1, product_Id);
			ps.setString(2, t);
			ps.setString(3, t1);
			ps.setInt(4, l);
			ps.setInt(5, b);
			ps.setInt(6, h);
			ps.setString(7,c);
			ps.setString(8, m);
			ps.setString(9,br);
			ps.setInt(10, p);
			ps.setString(11,de);
			ps.setString(12,s);
			ps.executeUpdate();
			System.out.println("vendor id is " +user.getVendor_UserId());
			RequestDispatcher rd = request.getRequestDispatcher("vendor_main2.jsp?p1=Product Added Successfully");
        	rd.forward(request, response);
        	
        	
        	
        
			String v_uid=user.getVendor_UserId();
			
			
			System.out.println("vebdor_main22" + v_uid);
			
		
				 Product_detail pd = V_Service_add.checkpro(v_uid);
				 System.out.println(pd);
				 
	    
				 if(pd!=null)
			        {
			        	
			       	 hts.setAttribute("pd", pd);
			       //	VendorInfo user=(VendorInfo)request.getAttribute("user");
			       	 
			       	 
			        	 rd = request.getRequestDispatcher("vendor_main2.jsp?");
			        	rd.forward(request, response);
			        }
		}
		
		if(t.equals("Service"))
		{
			String query2 = "select * from service_details";
			PreparedStatement ps2 = con.prepareStatement(query);
			ResultSet rs2 = ps.executeQuery();
			t= request.getParameter("selecttype");

			String t1= request.getParameter("choose_S");
			if(t1.equals("another"))
			{
				t1=request.getParameter("new_s");
			}
			String service_id=getV_Id();
			System.out.println(t1);
			int p= Integer.parseInt(request.getParameter("prices"));
			System.out.println(p);
			String de= request.getParameter("descs");
			System.out.println(de);
			String s= user.getVendor_UserId();
			System.out.println(s);
			System.out.println("p2");
			Service s1 = new Service(service_id,p,s,t,t1,de);
			//request.getRequestDispatcher("vendor_main.jsp").forward(request, response);
			hts.setAttribute("s1", s1);
			
			 String query1 = "insert into service_details values(?,?,?,?,?,?)" ;
	         ps=con.prepareStatement(query1);
		
			
			ps.setString(1, service_id);
			ps.setString(2, t);
			ps.setString(3, t1);
			
			ps.setInt(4, p);
			ps.setString(5,de);
			ps.setString(6,s);
			ps.executeUpdate();
			System.out.println("vendor id is " +user.getVendor_UserId());
			RequestDispatcher rd = request.getRequestDispatcher("vendor_main2.jsp?s1=Service Added Successfully");
		}

			
			request.getRequestDispatcher("vendor_main2.jsp?s2=Service Added Successfully").forward(request, response);
			
			System.out.println("p21");
			try {
				
	            
				
	           
	    
				
						} catch (Exception e) {
				e.printStackTrace();
			}
			System.out.println("p3");
			request.getRequestDispatcher("vendor_main2.jsp?msg2=Product added successfully.").forward(request, response);
		

	}catch (Exception e) 
	{
		System.out.print(e);
		
	}

}

}


