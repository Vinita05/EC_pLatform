package services;

import java.sql.*;


import com.dao.dataconn;

import P_model.Product_detail;
import v_model.VendorInfo;
import v_model.Vendordetails;
public class V_Service_add {
	
	
public static void addUser(VendorInfo u)
	{		
		try {
			Connection con =dataconn.connect();

			PreparedStatement ps = null;
            
            
            String query1 = "insert into vendor_info1 values(?,?,?,?,?,?,?)";
            ps=con.prepareStatement(query1);
            
			ps.setString(1, u.getfName());
			ps.setString(2, u.getlName());
			ps.setInt(3, u.getAge());
			ps.setString(4, u.getGender());
			ps.setLong(5, u.getContactNo());
			ps.setString(6, u.getVendor_UserId());
			ps.setString(7, u.getPassword());
			
			ps.executeUpdate();
			
					} catch (Exception e) {
			e.printStackTrace();
		}
	}

public static VendorInfo checkUser(String v_uid,String pwd) throws Exception
{
	VendorInfo ud =null;
	
	 Connection con = dataconn.connect();
     String query = "select * from vendor_info1 where vendor_userId=? and password=?";
     PreparedStatement ps = con.prepareStatement(query);
     ps.setString(1, v_uid);
     ps.setString(2, pwd);
     
     
     
     ResultSet rs = ps.executeQuery();
              
     if(rs.next())
     {

         System.out.println("user checked in check user if");
    	 ud=new VendorInfo(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getString(4), rs.getLong(5), rs.getString(6), rs.getString(7));
    	 return ud;
                         
     }
     else 
    	 

	/*}
	catch (Exception e) 
	  {
    	// 	e.printStackTrace();
    	 

    	 
    	 
     }*/
	
	
	return ud;
	
}
public static VendorInfo checkUser1() throws Exception
{
	VendorInfo ud =null;
	
	//try
//	{
	
	 Connection con = dataconn.connect();
     String query = "select * from vendor_info1";
     PreparedStatement ps = con.prepareStatement(query);
     ResultSet rs = ps.executeQuery();
              
     if(rs.next())
     {

         System.out.println("user checked in check user if 1");
    	 ud=new VendorInfo(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getString(4), rs.getLong(5), rs.getString(6), rs.getString(7));
    	 return ud;
                         
     }
     else 
    	 

	/*}
	catch (Exception e) 
	  {
    	// 	e.printStackTrace();
    	 

    	 
    	 
     }*/
	
	
	return ud;
	
}


public static String getV_Id()
{
	int id = 0;
	String id1="";
	try{
		Connection con = dataconn.connect();
		PreparedStatement ps= null;
		String query= "select max(vendor_Id) from vendor_detail";
		ps= con.prepareStatement(query);
		ResultSet rs = ps.executeQuery();
		if(rs.next()==false)
		{
			id=0;
		}
		else
		{
			id=Integer.parseInt(rs.getString(1).substring(2));
			System.out.println(id);
		}
		id=id+1;
		id1="v";
		id1=id1+String.format("%04d", id);
	}catch(Exception e)
	{
		System.out.println(e);
	}
	return id1;
}

/*
public static void addVendor(Vendordetails vd) throws SQLException
{
	
	Connection con =dataconn.connect();

	PreparedStatement ps = null;
	 String query1 = "insert into Vendor_detail values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
     ps=con.prepareStatement(query1);
     System.out.println("p2111");
		ps.setString(1,vd.getfName2());
		ps.setString(2, vd.getlName2());
		ps.setInt(3, vd.getAge2());
		ps.setString(4,vd.getGender2());
		ps.setLong(5, vd.getContactNo2());
		ps.setString(6, vd.getVendor_Id());
		ps.setString(7, vd.getAddress());
		ps.setString(8,vd.getCity());
		ps.setString(9, vd.getZipcode());
		ps.setString(10,vd.getLandline());
		ps.setString(11, vd.getEmail());
		ps.setString(12, vd.getOther());
		ps.setString(13, vd.getVendor_UserId());
		ps.executeUpdate();
	
}
*/



public static Vendordetails checkven(String v_uid) throws Exception
{
	Vendordetails vd =null;
	
	//try
//	{
	
	 Connection con = dataconn.connect();
     String query = "select * from vendor_detail where vendor_userId = ?";
     PreparedStatement ps = con.prepareStatement(query);
     ps.setString(1,v_uid);
     ResultSet rs = ps.executeQuery();
              
     if(rs.next())
     {

         System.out.println("userdeta checked in check user if 1");
    	 vd=new Vendordetails(rs.getString(1), rs.getString(2), rs.getInt(3), rs.getLong(5), rs.getString(4), rs.getString(13), rs.getString(6),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(10),rs.getString(11),rs.getString(12));
    	 return vd;
                         
     }
     else 
    	 

	/*}
	catch (Exception e) 
	  {
    	// 	e.printStackTrace();
    	 

    	 
    	 
     }*/
	
	
	return vd;
	
}


public static Product_detail checkpro(String v_uid) throws Exception
{
	Product_detail pd =null;
	
	//try
//	{
	
	 Connection con = dataconn.connect();
     String query = "select * from product_details where vendor_userId = ?";
     PreparedStatement ps = con.prepareStatement(query);
     ps.setString(1,v_uid);
     ResultSet rs = ps.executeQuery();
              
     if(rs.next())
     {

         System.out.println("userdeta checked in check user if 1");
    	 pd=new Product_detail(rs.getString(1), rs.getInt(4), rs.getInt(5), rs.getInt(6), rs.getInt(10), rs.getString(12), rs.getString(2),rs.getString(3),rs.getString(7),rs.getString(8),rs.getString(9),rs.getString(11));
    	 return pd;
                         
     }
     else 
    	 

	/*}
	catch (Exception e) 
	  {
    	// 	e.printStackTrace();
    	 

    	 
    	 
     }*/
	
	
	return pd;
	
}



}








